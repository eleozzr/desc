def fun():
	return('desc: hello world')
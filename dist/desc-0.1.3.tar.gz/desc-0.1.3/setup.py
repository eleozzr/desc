from setuptools import setup, find_packages

with open('README.md') as f:
    long_description = f.read()

setup(name = 'desc',
			version = '0.1.3',
			description = 'Deep Embedded Single cell rna-seq Clustering',
			long_description = long_description,
			long_description_content_type='text/markdown',
			classifiers = [
        'Development Status :: 3 - Alpha',
        'Programming Language :: Python :: 3',
      	],
			url = 'https://yafei611.github.io/desc/',
			author = 'Xiangjie Li, Gang Hu, Mingyao Li, Yafei Lyu',
			author_email = 'ele717@163.com, huggs@nankai.edu.cn, mingyao@pennmedicine.upenn.edu, lyuyafei@gmail.com',
			license = 'MIT',
			packages = find_packages(),
			install_requires = [
				'igraph', 'pydot', 'python-igraph', 'tensorflow'
				'keras', 'scanpy', 'pandas', 'louvain'
				],
			zip_safe = False
			)
			